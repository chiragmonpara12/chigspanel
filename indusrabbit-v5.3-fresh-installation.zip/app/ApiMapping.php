<?php
/**
 * Indusrabbit - SMM Panel script
 * Domain: https://indusrabbit.com/
 * Codecanyon Item: https://codecanyon.net/item/indusrabbit-smm-panel/19821624
 */
namespace App;

use Illuminate\Database\Eloquent\Model;

class ApiMapping extends Model
{
    protected $fillable = [
        'package_id',
        'api_package_id',
        'api_id',
    ];
}