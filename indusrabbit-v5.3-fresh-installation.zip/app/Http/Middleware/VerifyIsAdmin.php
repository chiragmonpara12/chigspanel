<?php
/**
 * Indusrabbit - SMM Panel script
 * Domain: https://indusrabbit.com/
 * Codecanyon Item: https://codecanyon.net/item/indusrabbit-smm-panel/19821624
 *
 */
namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class VerifyIsAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(Auth::user()->role != 'ADMIN'){
            abort(403);
        }

        config(['app.timezone' => getOption('timezone')]);
        return $next($request);
    }
}
