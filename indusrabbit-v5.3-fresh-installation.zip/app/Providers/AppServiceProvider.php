<?php
/**
 * Indusrabbit - SMM Panel script
 * Domain: https://indusrabbit.com/
 * Codecanyon Item: https://codecanyon.net/item/indusrabbit-smm-panel/19821624
 *
 */
namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
//        Schema::defaultStringLength(191);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
