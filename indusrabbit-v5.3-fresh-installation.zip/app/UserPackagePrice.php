<?php
/**
 * Indusrabbit - SMM Panel script
 * Domain: https://indusrabbit.com/
 * Codecanyon Item: https://codecanyon.net/item/indusrabbit-smm-panel/19821624
 *
 */
namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPackagePrice extends Model
{
    protected $fillable = [
        'user_id',
        'package_id',
        'price_per_item',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function package()
    {
        return $this->belongsTo(Package::class);
    }
}
