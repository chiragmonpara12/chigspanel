﻿<?php

return [

    'login' => 'تسجيل الدخول',
    'update' => 'تحديث',
    'create_new' => 'انشاء جديد',
    'create' => 'انشاء',
    'send' => 'إرسال',
    'proceed' => 'المتابعة',
    'pay' => 'دفع',
    'new_order' => 'طلب جديد',
    'see_packages' => 'انظر الباقة',
    'place_order' => 'اعتمد الطلب',
    'create_new_ticket' => 'إنشاء تذكرة جديدة',
    'register' => 'تسجيل',
    'generate' => 'توليد',
    'send_password_reset' => 'ارسال رابط إعادة تعيين كلمة المرور',
    'reset_password' => 'إعادة تعيين كلمة المرور',
    'add_new' => 'اضف جديد',
    'order_now' => 'اطلب الان',
    'get_status' => 'الحصول على الحالة',
    'regenerate' => 'اعادة توليد',
    'add' => 'إضافة',
    'change_reseller' => 'تغيير المورد',
];
