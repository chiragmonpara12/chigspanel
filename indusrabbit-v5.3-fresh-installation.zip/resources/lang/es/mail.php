<?php
return [
    'ticket_submitted_subject' => 'Se crea un nuevo ticket de soporte.',
    'ticket_message_subject' => 'Has recibido un nuevo mensaje.',
    'message' => 'Mensaje',
    'description' => 'Descripción',
    'subject' => 'Tema',
    'ticket_id' => 'Identificación de entradas',
    'user' => 'Usuario',
    'system_status_report' => 'Informe de estado del sistema',
    'orders' => 'Pedidos',
    'tickets' => 'Entradas',
    'users' => 'Usuarios',
    'new' => 'Nuevo',
    'total' => 'Total',
    'today' => 'Hoy',
    'this_month' => 'Este mes',
    'lifetime' => 'Toda la vida',

];