<?php

return [

    'login' => 'Login',
    'update' => 'Aggiorna',
    'create_new' => 'Crea Nuovo',
    'create' => 'Crea',
    'send' => 'Invia',
    'proceed' => 'Procedi',
    'pay' => 'Paga',
    'new_order' => 'Nuovo Ordine',
    'see_packages' => 'Vedi prodotti',
    'place_order' => 'Invia ordine',
    'create_new_ticket' => 'Crea nuovo ticket',
    'register' => 'Registrati',
    'generate' => 'Genera',
    'send_password_reset' => 'Invia il link di reset password.',
    'reset_password' => 'Reset Password',
    'add_new' => 'Aggiungi Nuovo',
    'order_now' => 'Ordina ora',
    'get_status' => 'Ottieni lo stato',
    'regenerate' => 'Rigenerare',
    'add' => 'Inserisci',
    'change_reseller' => 'Modifica rivenditore',

];
