<?php
return [
    'ticket_submitted_subject' => 'Viene creato un nuovo biglietto di supporto.',
    'ticket_message_subject' => 'Hai ricevuto un nuovo messaggio.',
    'message' => 'Messaggio',
    'description' => 'Descrizione',
    'subject' => 'Soggetto',
    'ticket_id' => 'TicketID',
    'user' => 'Utente',
    'system_status_report' => 'Rapporto sullo stato del sistema',
    'orders' => 'Ordini',
    'tickets' => 'Biglietti',
    'users' => 'utenti',
    'new' => 'Nuovo',
    'total' => 'Totale',
    'today' => 'Oggi',
    'this_month' => 'Questo mese',
    'lifetime' => 'Tutta la vita',

];