<?php

return [

    'login' => 'Entrar',
    'update' => 'Atualizar',
    'create_new' => 'Crie um novo',
    'create' => 'Crio',
    'send' => 'Enviar',
    'proceed' => 'Prosseguir',
    'pay' => 'Pagamento',
    'new_order' => 'Nova ordem',
    'see_packages' => 'Ver Pacotes',
    'place_order' => 'Faça a encomenda',
    'create_new_ticket' => 'Criar novo ticket',
    'register' => 'Registo',
    'generate' => 'Gerar',
    'send_password_reset' => 'Enviar link de redefinição de senha',
    'reset_password' => 'Trocar a senha',
    'add_new' => 'Adicionar novo',
    'order_now' => 'Peça agora',
    'get_status' => 'Obter Status',
    'regenerate' => 'Regenerado',
    'add' => 'Adicionar',
    'change_reseller' => 'Revenda de revenda',

];
