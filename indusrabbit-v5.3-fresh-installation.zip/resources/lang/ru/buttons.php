<?php

return [

    'login' => 'Авторизоваться',
    'update' => 'Обновить',
    'create_new' => 'Создавать новое',
    'create' => 'Создайте',
    'send' => 'послать',
    'proceed' => 'проследовать',
    'pay' => 'платить',
    'new_order' => 'Новый заказ',
    'see_packages' => 'См. Пакеты',
    'place_order' => 'Разместить заказ',
    'create_new_ticket' => 'Создать новый билет',
    'register' => 'регистр',
    'generate' => 'генерировать',
    'send_password_reset' => 'Ссылка для сброса пароля',
    'reset_password' => 'Сброс пароля',
    'add_new' => 'Добавить новое',
    'order_now' => 'Заказать сейчас',
    'get_status' => 'Получить статус',
    'regenerate' => 'регенерировать',
    'add' => 'Добавить',
    'change_reseller' => 'Изменить реселлера',

];
