<?php

return [

    'login' => 'เข้าสู่ระบบ',
    'update' => 'อัพเดท',
    'create_new' => 'สร้างใหม่',
    'create' => 'สร้าง',
    'send' => 'ส่ง',
    'proceed' => 'ดำเนินการ',
    'pay' => 'จ่ายเงิน',
    'new_order' => 'คำสั่งงานใหม่',
    'see_packages' => 'ดูแพคเกจ',
    'place_order' => 'สั่งงาน',
    'create_new_ticket' => 'ส่งข้อความ หาหมาน้อย',
    'register' => 'สมัครสมาชิก',
    'generate' => 'สุ่ม',
    'send_password_reset' => 'ส่งลิงก์รีเซ็ตรหัสผ่าน',
    'reset_password' => 'รีเซ็ตรหัสผ่าน',
    'add_new' => 'เพิ่มใหม่',
    'order_now' => 'สั่งงานทันที',
    'get_status' => 'ดูสถานะ',
    'regenerate' => 'สุ่มใหม่',
    'add' => 'เพิ่ม',
    'change_reseller' => 'เปลี่ยน Reseller',
];
