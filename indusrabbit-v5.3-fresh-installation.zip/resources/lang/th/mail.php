<?php
return [
    'ticket_submitted_subject' => 'มีการส่งข้อความใหม่',
    'ticket_message_subject' => 'คุณได้รับข้อความใหม่แล้ว',
    'message' => 'ข้อความ',
    'description' => 'คำอธิบาย',
    'subject' => 'เรื่อง',
    'ticket_id' => 'รหัสข้อความ',
    'user' => 'ผู้ใช้งาน',
    'system_status_report' => 'รายงานสถานะระบบ',
    'orders' => 'คำสั่งซื้อ',
    'tickets' => 'ข้อความ',
    'users' => 'ผู้ใช้งาน',
    'new' => 'ใหม่',
    'total' => 'ทั้งหมด',
    'today' => 'วันนี้',
    'this_month' => 'เดือนนี้',
    'lifetime' => 'ตลอดอายุ',

];