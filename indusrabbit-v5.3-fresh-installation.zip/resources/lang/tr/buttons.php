<?php

return [

    'login' => 'Giris',
    'update' => 'Guncelle',
    'create_new' => 'Yeni Olustur',
    'create' => 'Yeni',
    'send' => 'Gonder',
    'proceed' => 'Ilerleme',
    'pay' => 'odeme',
    'new_order' => 'Yeni Siparis',
    'see_packages' => 'Paketleri Goruntule',
    'place_order' => 'Siparis Ver',
    'create_new_ticket' => 'Destek Talebi Olustur',
    'register' => 'Uye Ol',
    'generate' => 'Uret',
    'send_password_reset' => 'Sifre Sifirlama Baglanti Gonder',
    'reset_password' => 'sifremi Sifirla',
    'add_new' => 'Yeni Ekle',
    'order_now' => 'Simdi Siparis Ver',
    'get_status' => 'Durum',
    'regenerate' => 'canlandırmak',
    'add' => 'Eklemek',
    'change_reseller' => 'Bayiyi Değiştir',

];
