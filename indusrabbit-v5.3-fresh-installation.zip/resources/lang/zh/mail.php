<?php
return [
    'ticket_submitted_subject' => '创建一个新的支持票据。',
    'ticket_message_subject' => '您收到一条新消息。',
    'message' => '信息',
    'description' => '描述',
    'subject' => '学科',
    'ticket_id' => '票证号码',
    'user' => '用户',
    'system_status_report' => '系统状态报告',
    'orders' => '命令',
    'tickets' => '门票',
    'users' => '用户',
    'new' => '新',
    'total' => '总',
    'today' => '今天',
    'this_month' => '这个月',
    'lifetime' => '一生',

];