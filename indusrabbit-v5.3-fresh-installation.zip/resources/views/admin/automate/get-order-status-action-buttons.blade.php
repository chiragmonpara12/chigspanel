<button class="get-status btn btn-primary btn-sm" data-id="{{$id}}"><span>@lang('buttons.get_status')</span></button> |
<button class="change-reseller btn btn-danger btn-sm" data-id="{{$id}}"><span>@lang('buttons.change_reseller')</span></button>
