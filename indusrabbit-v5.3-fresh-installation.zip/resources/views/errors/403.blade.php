@extends('errors::layout')

@section('title', 'Access Denied')

@section('message', 'You do not have permission to view this page.')
