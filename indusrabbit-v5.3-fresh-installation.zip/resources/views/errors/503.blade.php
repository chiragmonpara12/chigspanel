@extends('errors::layout')

@section('title', 'License Invalid Error')

@section('message')
    This domain is not registered with a valid purchase code.<br/>
    If you think it is a mistake, please ask support<br/>
    <a target="_blank" href="https://codecanyon.net/item/indusrabbit-smm-panel/19821624/comments" rel="noopener nofollow">
        Here
    </a>
@endsection
